<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Notifications\Notifiable;

class Productos extends Model
{

    protected $table = 'productos';
    use Notifiable;

    protected $fillable = [
        'Matricula','name','almacen','tipo','permiso','cantidad','disponible','detalles'
    ];
    protected $casts = [
        'cantidad' => 'integer',
    ];
}
